/*************************************************************************/ /*
 VCP core module

 Copyright (C) 2015 - 2018 Renesas Electronics Corporation

 License        Dual MIT/GPLv2

 The contents of this file are subject to the MIT license as set out below.

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.

 Alternatively, the contents of this file may be used under the terms of
 the GNU General Public License Version 2 ("GPL") in which case the provisions
 of GPL are applicable instead of those above.

 If you wish to allow use of your version of this file only under the terms of
 GPL, and not to allow others to use your version of this file under the terms
 of the MIT license, indicate your decision by deleting the provisions above
 and replace them with the notice and other provisions required by GPL as set
 out in the file called "GPL-COPYING" included in this distribution. If you do
 not delete the provisions above, a recipient may use your version of this file
 under the terms of either the MIT license or GPL.

 This License is also included in this distribution in the file called
 "MIT-COPYING".

 EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 GPLv2:
 If you wish to use this file under the terms of GPL, following terms are
 effective.

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; version 2 of the License.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/ /*************************************************************************/

#ifndef MCVX_ARCH_VCP3_H
#define MCVX_ARCH_VCP3_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "mcvx_register.h"
#include "mcvx_arch_fcpc.h"

/* VP ADDRESS */
#define MCVX_VCP3_VP_ADDR_TOP	( 0x08000000u )

#define MCVX_VCP3_CH_R			( 0u )
#define MCVX_VCP3_CH_W			( 1u )

#define MCVX_VCP3_TL_V32		( 1u )
#define MCVX_VCP3_TL_H128		( 3u )

/* edt max */
/* PIC_CNT_MAX  = 6000 x 34560 (as 4K MBs) >>16 = 3164 = 0xC5C */
/* MB_CNT_MAX   = 0 (ignore) */
/* SRST_CNT_MAX = 1			 */
#define	MCVX_VCP3_VLC_EDT_VAL	( 0x0C5C0001u )
#define	MCVX_VCP3_CE_EDT_VAL	( 0x0C5C0001u )

/*----------------------------------------------------------------------------------------------------------*/
/* PAR0 macro																								*/
/*----------------------------------------------------------------------------------------------------------*/
#define MCVX_PACK_VCP3_VLC_DEC_PAR0_H													\
	( ( ( MCVX_M_01BIT & vlc_dec->cmn_par->tmp_placement )			<<	(56-32)	)		\
	| ( ( MCVX_M_01BIT & vlc_dec->cmn_par->ref_placement )			<<	(55-32)	)		\
	| ( ( MCVX_M_01BIT & vlc_dec->cmn_par->mode )					<<	(54-32)	)		\
	| ( ( MCVX_M_05BIT & vlc_dec->cmn_par->hw_stream_type )			<<	(49-32)	)		\
	| ( ( MCVX_M_01BIT & vlc_dec->cmn_par->padding_pic_edge )		<<	(48-32)	)		\
	| ( ( MCVX_M_01BIT & vlc_dec->cmn_par->dec_out_disable )		<<	(43-32)	)		\
	| ( ( MCVX_M_01BIT & vlc_dec->cmn_par->mv_info_out )			<<	(40-32)	) )		\

#define MCVX_PACK_VCP3_VLC_DEC_PAR0_L													\
	( ( ( MCVX_M_14BIT & vlc_dec->cmn_par->pic_width_m1 )			<<		18	)		\
	| ( ( MCVX_M_14BIT & vlc_dec->cmn_par->pic_height_m1 )			<<		 4	)		\
	| ( ( MCVX_M_01BIT & vlc_dec->cmn_par->interlace )				<<		 3	)		\
	| ( ( MCVX_M_01BIT & vlc_dec->cmn_par->field_pic_flag )			<<		 2	)		\
	| ( ( MCVX_M_01BIT & vlc_dec->cmn_par->bottom_field_flag )		<<		 1	)		\
	| ( ( MCVX_M_01BIT & vlc_dec->cmn_par->top_field_first )		<<		 0	) )		\

#define MCVX_PACK_VCP3_CE_DEC_PAR0_H													\
	( ( ( MCVX_M_01BIT & ce_dec->cmn_par->tmp_placement )			<<	(56-32)	)		\
	| ( ( MCVX_M_01BIT & ce_dec->cmn_par->ref_placement )			<<	(55-32)	)		\
	| ( ( MCVX_M_01BIT & ce_dec->cmn_par->mode )					<<	(54-32)	)		\
	| ( ( MCVX_M_05BIT & ce_dec->cmn_par->hw_stream_type )			<<	(49-32)	)		\
	| ( ( MCVX_M_01BIT & ce_dec->cmn_par->padding_pic_edge )		<<	(48-32)	)		\
	| ( ( MCVX_M_01BIT & ce_dec->cmn_par->dec_out_disable )			<<	(43-32)	)		\
	| ( ( MCVX_M_01BIT & ce_dec->cmn_par->mv_info_out )				<<	(40-32)	) )		\

#define MCVX_PACK_VCP3_CE_DEC_PAR0_L													\
	( ( ( MCVX_M_14BIT & ce_dec->cmn_par->pic_width_m1 )			<<		18	)		\
	| ( ( MCVX_M_14BIT & ce_dec->cmn_par->pic_height_m1 )			<<		 4	)		\
	| ( ( MCVX_M_01BIT & ce_dec->cmn_par->interlace )				<<		 3	)		\
	| ( ( MCVX_M_01BIT & ce_dec->cmn_par->field_pic_flag )			<<		 2	)		\
	| ( ( MCVX_M_01BIT & ce_dec->cmn_par->bottom_field_flag )		<<		 1	)		\
	| ( ( MCVX_M_01BIT & ce_dec->cmn_par->top_field_first )			<<		 0	) )		\

#define MCVX_PACK_VCP3_VLC_ENC_PAR0_H													\
	( ( ( MCVX_M_01BIT & vlc_enc->cmn_par->tmp_placement )			<<	(56-32)	)		\
	| ( ( MCVX_M_01BIT & vlc_enc->cmn_par->ref_placement )			<<	(55-32)	)		\
	| ( ( MCVX_M_01BIT & vlc_enc->cmn_par->mode )					<<	(54-32)	)		\
	| ( ( MCVX_M_05BIT & vlc_enc->cmn_par->hw_stream_type )			<<	(49-32)	)		\
	| ( ( MCVX_M_01BIT & vlc_enc->cmn_par->padding_pic_edge )		<<	(48-32)	)		\
	| ( ( MCVX_M_01BIT & vlc_enc->cmn_par->dec_out_disable )		<<	(43-32)	)		\
	| ( ( MCVX_M_01BIT & vlc_enc->cmn_par->mv_info_out )			<<	(40-32)	) )		\

#define MCVX_PACK_VCP3_VLC_ENC_PAR0_L													\
	( ( ( MCVX_M_14BIT & vlc_enc->cmn_par->pic_width_m1 )			<<		18	)		\
	| ( ( MCVX_M_14BIT & vlc_enc->cmn_par->pic_height_m1 )			<<		 4	)		\
	| ( ( MCVX_M_01BIT & vlc_enc->cmn_par->interlace )				<<		 3	)		\
	| ( ( MCVX_M_01BIT & vlc_enc->cmn_par->field_pic_flag )			<<		 2	)		\
	| ( ( MCVX_M_01BIT & vlc_enc->cmn_par->bottom_field_flag )		<<		 1	)		\
	| ( ( MCVX_M_01BIT & vlc_enc->cmn_par->top_field_first )		<<		 0	) )		\

#define MCVX_PACK_VCP3_CE_ENC_PAR0_H													\
	( ( ( MCVX_M_01BIT & ce_enc->cmn_par->tmp_placement )			<<	(56-32)	)		\
	| ( ( MCVX_M_01BIT & ce_enc->cmn_par->ref_placement )			<<	(55-32)	)		\
	| ( ( MCVX_M_01BIT & ce_enc->cmn_par->mode )					<<	(54-32)	)		\
	| ( ( MCVX_M_05BIT & ce_enc->cmn_par->hw_stream_type )			<<	(49-32)	)		\
	| ( ( MCVX_M_01BIT & ce_enc->cmn_par->padding_pic_edge )		<<	(48-32)	)		\
	| ( ( MCVX_M_01BIT & ce_enc->cmn_par->dec_out_disable )			<<	(43-32)	)		\
	| ( ( MCVX_M_01BIT & ce_enc->cmn_par->mv_info_out )				<<	(40-32)	) )		\

#define MCVX_PACK_VCP3_CE_ENC_PAR0_L													\
	( ( ( MCVX_M_14BIT & ce_enc->cmn_par->pic_width_m1 )			<<		18	)		\
	| ( ( MCVX_M_14BIT & ce_enc->cmn_par->pic_height_m1 )			<<		 4	)		\
	| ( ( MCVX_M_01BIT & ce_enc->cmn_par->interlace )				<<		 3	)		\
	| ( ( MCVX_M_01BIT & ce_enc->cmn_par->field_pic_flag )			<<		 2	)		\
	| ( ( MCVX_M_01BIT & ce_enc->cmn_par->bottom_field_flag )		<<		 1	)		\
	| ( ( MCVX_M_01BIT & ce_enc->cmn_par->top_field_first )			<<		 0	) )		\

/*----------------------------------------------------------------------------------------------------------*/
/* NOP IRP template																							*/
/*----------------------------------------------------------------------------------------------------------*/
#define MCVX_VCP3_NOP_PACKET		\
	do{ 							\
		MCVX_IR_W0 = 0x00000010u;	\
		MCVX_IR_W1 = 0x00000000u;	\
		MCVX_IR_W2 = 0x00000000u;	\
		MCVX_IR_W3 = 0x00000000u;	\
		tail += MCVX_IR_SIZEOF_4W; 	\
	}while(0)

/*----------------------------------------------------------------------------------------------------------*/
/* DMA BA template																							*/
/*----------------------------------------------------------------------------------------------------------*/
#define MCVX_VCP3_FMT_VLC_DMA_BA_X( BA_OFFSET, STRIDE, ADDR )	\
	do{ 														\
		MCVX_IR_W0 = 0u;										\
		MCVX_IR_W1 = ( MCVX_VCP3_VP_ADDR_TOP + ( BA_OFFSET ) );	\
		MCVX_IR_W2 = ( ( STRIDE ) >> 4u );						\
		MCVX_IR_W3 = ( ADDR );	 								\
		tail += MCVX_IR_SIZEOF_4W; 								\
	}while(0)


#define MCVX_VCP3_FMT_CE_DMA_BA_X( BA_OFFSET, STRIDE, ADDR )	\
	do{ 														\
		MCVX_IR_W0 = 0u;										\
		MCVX_IR_W1 = ( MCVX_VCP3_VP_ADDR_TOP + ( BA_OFFSET ) );	\
		MCVX_IR_W2 = ( ( STRIDE ) >> 4u );						\
		MCVX_IR_W3 = ( ADDR );	 								\
		tail += MCVX_IR_SIZEOF_4W; 								\
	}while(0)

/*----------------------------------------------------------------------------------------------------------*/
/* DMA CHANNEL template			                                                                            */
/*----------------------------------------------------------------------------------------------------------*/
#define MCVX_VCP3_FMT_CMN_DCHR_X( VP_OFFSET, BAAP_OR_TLV, LISTID_OR_TLH, AM, TM, QUEID, WR, ENDIAN )	\
	do{ 																								\
		MCVX_IR_W0 = 0u;																			\
		MCVX_IR_W1 = MCVX_VCP3_VP_ADDR_TOP + ( VP_OFFSET );											\
		MCVX_IR_W2 = 0u;																			\
		MCVX_IR_W3 =																				\
					( ( ( MCVX_M_01BIT & ( 1u ) )				<< 31 )								\
					| ( ( MCVX_M_06BIT & ( BAAP_OR_TLV ) )		<< 18 )								\
					| ( ( MCVX_M_04BIT & ( LISTID_OR_TLH ) )	<< 14 )								\
					| ( ( MCVX_M_03BIT & ( AM ) )				<< 11 )								\
					| ( ( MCVX_M_02BIT & ( TM ) )				<<  9 )								\
					| ( ( MCVX_M_03BIT & ( QUEID ) )			<<  6 )								\
					| ( ( MCVX_M_01BIT & ( WR ) )				<<  5 )								\
					| ( ( MCVX_M_04BIT & ( ENDIAN ) )			<<  0 ) ); 							\
		tail += MCVX_IR_SIZEOF_4W; 																	\
	}while(0)

#define MCVX_VCP3_FMT_IMG_DCHR_X( VP_OFFSET, DECPIC, YC, TOPBOT, TLV, TLH, AM, TM, QUEID, WR, ENDIAN )	\
	do{ 																								\
		MCVX_IR_W0 = 0u;																			\
		MCVX_IR_W1 = MCVX_VCP3_VP_ADDR_TOP + ( VP_OFFSET );											\
		MCVX_IR_W2 = 0u;																			\
		MCVX_IR_W3 =																				\
					( ( ( MCVX_M_01BIT & ( 1u ) )				<< 31 )								\
					| ( ( MCVX_M_01BIT & ( DECPIC ) )			<< 30 )								\
					| ( ( MCVX_M_01BIT & ( YC ) )				<< 29 )								\
					| ( ( MCVX_M_01BIT & ( TOPBOT ) )			<< 28 )								\
					| ( ( MCVX_M_06BIT & ( TLV ) )				<< 18 )								\
					| ( ( MCVX_M_04BIT & ( TLH ) )				<< 14 )								\
					| ( ( MCVX_M_03BIT & ( AM ) )				<< 11 )								\
					| ( ( MCVX_M_02BIT & ( TM ) )				<<  9 )								\
					| ( ( MCVX_M_03BIT & ( QUEID ) )			<<  6 )								\
					| ( ( MCVX_M_01BIT & ( WR ) )				<<  5 )								\
					| ( ( MCVX_M_04BIT & ( ENDIAN ) )			<<  0 ) ); 							\
		tail += MCVX_IR_SIZEOF_4W; 																	\
	}while(0)

/* only for STB */
#define MCVX_VCP3_FMT_DCHR_CM1( VP_OFFSET, BAAP_OR_TLV, LISTID_OR_TLH, AM, TM, QUEID, WR, ENDIAN )	\
	do{ 																							\
		MCVX_IR_W0 = 0u;																			\
		MCVX_IR_W1 = MCVX_VCP3_VP_ADDR_TOP + ( VP_OFFSET );											\
		MCVX_IR_W2 = 0u;																			\
		MCVX_IR_W3 =																				\
					( ( ( MCVX_M_01BIT & ( 1u ) )				<< 31 )								\
					| ( ( MCVX_M_01BIT & ( 1u ) )				<< 27 )								\
					| ( ( MCVX_M_06BIT & ( BAAP_OR_TLV ) )		<< 18 )								\
					| ( ( MCVX_M_04BIT & ( LISTID_OR_TLH ) )	<< 14 )								\
					| ( ( MCVX_M_03BIT & ( AM ) )				<< 11 )								\
					| ( ( MCVX_M_02BIT & ( TM ) )				<<  9 )								\
					| ( ( MCVX_M_03BIT & ( QUEID ) )			<<  6 )								\
					| ( ( MCVX_M_01BIT & ( WR ) )				<<  5 )								\
					| ( ( MCVX_M_04BIT & ( ENDIAN ) )			<<  0 ) ); 							\
		tail += MCVX_IR_SIZEOF_4W; 																	\
	}while(0)

#define MCVX_VCP3_FMT_DATA( EMASK, VP_ADDR, DATA_H, DATA_L )			\
	do{ 																\
		MCVX_IR_W0 = ( ( MCVX_M_06BIT & ( EMASK ) ) << 24 );			\
		MCVX_IR_W1 = ( VP_ADDR );										\
		MCVX_IR_W2 = ( DATA_H );										\
		MCVX_IR_W3 = ( DATA_L );										\
		tail += MCVX_IR_SIZEOF_4W; 										\
	}while(0)

#define MCVX_VCP3_DCHR_DIRECT( BAAP_OR_TLV, LISTID_OR_TLH, AM, TM, QUEID, WR, ENDIAN )	\
	( ( ( MCVX_M_01BIT & ( 1u ) )				<< 31 )									\
	| ( ( MCVX_M_06BIT & ( BAAP_OR_TLV ) )		<< 18 )									\
	| ( ( MCVX_M_04BIT & ( LISTID_OR_TLH ) )	<< 14 )									\
	| ( ( MCVX_M_03BIT & ( AM ) )				<< 11 )									\
	| ( ( MCVX_M_02BIT & ( TM ) )				<<  9 )									\
	| ( ( MCVX_M_03BIT & ( QUEID ) )			<<  6 )									\
	| ( ( MCVX_M_01BIT & ( WR ) )				<<  5 )									\
	| ( ( MCVX_M_04BIT & ( ENDIAN ) )			<<  0 ) ) 								\

/*----------------------------------------------------------------------------------------------------------*/
/*							                                                                                */
/* DMA BASE ADDRESS			                                                                                */
/*							                                                                                */
/*----------------------------------------------------------------------------------------------------------*/

/* see hw-manual Table 3-1: Description of Base Address Array of VLC */

/* LIST ITEM */
#define MCVX_VCP3_VP_VLC_BA_R_LIST_ITEM( ADDR )				MCVX_VCP3_FMT_VLC_DMA_BA_X( 0x0081u,					0u,		( ADDR ) )

/* MISC STUFF (DEC) */
#define MCVX_VCP3_VP_VLC_BA_RW_SEG( ADDR )					MCVX_VCP3_FMT_VLC_DMA_BA_X( 0x00ABu,					0u,		( ADDR ) )
#define MCVX_VCP3_VP_VLC_BA_RW_MBI( ADDR )					MCVX_VCP3_FMT_VLC_DMA_BA_X( 0x00ACu,					0u,		( ADDR ) )
#define MCVX_VCP3_VP_VLC_BA_R_BP_DP_PROB( ADDR )			MCVX_VCP3_FMT_VLC_DMA_BA_X( 0x00ADu,					0u,		( ADDR ) )
#define MCVX_VCP3_VP_VLC_BA_W_BP_DP_PROB( ADDR )			MCVX_VCP3_FMT_VLC_DMA_BA_X( 0x00AEu,					0u,		( ADDR ) )
#define MCVX_VCP3_VP_VLC_BA_W_COL( ADDR )					MCVX_VCP3_FMT_VLC_DMA_BA_X( 0x00AFu,					0u,		( ADDR ) )
#define MCVX_VCP3_VP_VLC_BA_R_COL( ADDR, IDX )				MCVX_VCP3_FMT_VLC_DMA_BA_X( 0x00B0u + (IDX),			0u,		( ADDR ) )

/* MISC STUFF (ENC) */
#define MCVX_VCP3_VP_VLC_BA_R_ENC_PROB_BASE( ADDR )			MCVX_VCP3_FMT_VLC_DMA_BA_X( 0x00A9u,					0u,		( ADDR ) )
#define MCVX_VCP3_VP_VLC_BA_R_ENC_PROB_UPDATE( ADDR )		MCVX_VCP3_FMT_VLC_DMA_BA_X( 0x00AAu,					0u,		( ADDR ) )
#define MCVX_VCP3_VP_VLC_BA_W_ENC_STAT( ADDR )				MCVX_VCP3_FMT_VLC_DMA_BA_X( 0x00ABu,					0u,		( ADDR ) )
#define MCVX_VCP3_VP_VLC_BA_R_ENC_DP_COEF0( ADDR )			MCVX_VCP3_FMT_VLC_DMA_BA_X( 0x00ADu,					0u,		( ADDR ) )
#define MCVX_VCP3_VP_VLC_BA_R_ENC_DP_COEF1( ADDR )			MCVX_VCP3_FMT_VLC_DMA_BA_X( 0x00AEu,					0u,		( ADDR ) )

/* see hw-manual Table 3-66: Description of Base Address Array of CE */
/* IMAGE STUFF */
#define MCVX_VCP3_VP_CE_BA_R_ENC_TOP_Y( STRIDE, ADDR )		MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00A0u,					( STRIDE ), ( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_R_ENC_TOP_C( STRIDE, ADDR )		MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00A1u,					( STRIDE ), ( ADDR ) )

#define MCVX_VCP3_VP_CE_BA_R_ENC_TOP_CB( STRIDE, ADDR )		MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00A1u,					( STRIDE ), ( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_R_ENC_TOP_CR( STRIDE, ADDR )		MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00A2u,					( STRIDE ), ( ADDR ) )

#define MCVX_VCP3_VP_CE_BA_W_DEC_TOP_Y( STRIDE, ADDR )		MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00A3u,					( STRIDE ), ( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_W_DEC_TOP_C( STRIDE, ADDR )		MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00A4u,					( STRIDE ), ( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_W_DEC_BOT_Y( STRIDE, ADDR )		MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00A5u,					( STRIDE ), ( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_W_DEC_BOT_C( STRIDE, ADDR )		MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00A6u,					( STRIDE ), ( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_W_FLT_TOP_Y( STRIDE, ADDR )		MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00A7u,					( STRIDE ), ( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_W_FLT_TOP_C( STRIDE, ADDR )		MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00A8u,					( STRIDE ), ( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_W_FLT_BOT_Y( STRIDE, ADDR )		MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00A9u,					( STRIDE ), ( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_W_FLT_BOT_C( STRIDE, ADDR )		MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00AAu,					( STRIDE ), ( ADDR ) )

#define MCVX_VCP3_VP_CE_BA_R_REF_Y( STRIDE, ADDR, IDX )		MCVX_VCP3_FMT_CE_DMA_BA_X( ( 0x00C0u + ((IDX)*2u) ),	( STRIDE ), ( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_R_REF_C( STRIDE, ADDR, IDX )		MCVX_VCP3_FMT_CE_DMA_BA_X( ( 0x00C1u + ((IDX)*2u) ),	( STRIDE ), ( ADDR ) )

/* FCV */
#define MCVX_VCP3_VP_CE_BA_R_FCV_Y( STRIDE, ADDR )			MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00ABu,					( STRIDE ), ( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_R_FCV_C( STRIDE, ADDR )			MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00ACu,					( STRIDE ), ( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_W_FCV_Y( STRIDE, ADDR )			MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00ADu,					( STRIDE ), ( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_W_FCV_U( STRIDE, ADDR )			MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00AEu,					( STRIDE ), ( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_W_FCV_V( STRIDE, ADDR )			MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00AFu,					( STRIDE ), ( ADDR ) )

/* MISC STUFF */
#define MCVX_VCP3_VP_CE_BA_RW_MBI( ADDR )					MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00B0u,					0u,		( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_COL_R( ADDR )					MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00B1u,					0u,		( ADDR ) )
/*																					  0x00B2u reserved			*/
#define MCVX_VCP3_VP_CE_BA_COL_W( ADDR )					MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00B3u,					0u,		( ADDR ) )
/*																					  0x00B4u reserved			*/
#define MCVX_VCP3_VP_CE_BA_R_PRD( ADDR )					MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00B5u,					0u,		( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_R_OVT( ADDR )					MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00B6u,					0u,		( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_R_DEB( ADDR )					MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00B7u,					0u,		( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_W_PRD( ADDR )					MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00B8u,					0u,		( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_W_OVT( ADDR )					MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00B9u,					0u,		( ADDR ) )
#define MCVX_VCP3_VP_CE_BA_W_DEB( ADDR )					MCVX_VCP3_FMT_CE_DMA_BA_X( 0x00BAu,					0u,		( ADDR ) )

/*----------------------------------------------------------------------------------------------------------*/
/*							                                                                                */
/* DMA CHANNEL				                                                                                */
/*							                                                                                */
/*----------------------------------------------------------------------------------------------------------*/
/* see hw-manual Table 3-3: Description of DMA channel registers of VLC */
/* ES STUFF (VLC) */																/*	VP_ADDR,	as BAAP,	as LISTID,	AM,	TM,	QUEID,	WR,				ENDIAN */
#define MCVX_VCP3_VP_VLC_DCHR_R_ES_MAIN( ENDIAN )			MCVX_VCP3_FMT_CMN_DCHR_X(	0x0016u,	16u,		0u,			0u,	1u,	0u,		MCVX_VCP3_CH_R,	( ENDIAN ) )
#define MCVX_VCP3_VP_VLC_DCHR_R_ES_SUB( ENDIAN )			MCVX_VCP3_FMT_CMN_DCHR_X(	0x0017u,	17u,		1u,			0u,	1u,	0u,		MCVX_VCP3_CH_R,	( ENDIAN ) )
#define MCVX_VCP3_VP_VLC_DCHR_W_ES_MAIN( ENDIAN )			MCVX_VCP3_FMT_CMN_DCHR_X(	0x0016u,	16u,		0u,			0u,	1u,	0u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#define MCVX_VCP3_VP_VLC_DCHR_W_ES_SUB( ENDIAN )			MCVX_VCP3_FMT_CMN_DCHR_X(	0x0017u,	17u,		1u,			0u,	1u,	0u,		MCVX_VCP3_CH_W,	( ENDIAN ) )

/* ES read via STB */
#define MCVX_VCP3_VP_VLC_DCHR_R_ES_STB( ENDIAN )			MCVX_VCP3_FMT_CMN_DCHR_X(	0x0016u,	16u,		0u,			4u,	1u,	0u,		MCVX_VCP3_CH_R,	( ENDIAN ) )

/* ES STUFF (LIST ITEM LOAD) */														/*	VP_ADDR,	as BAAP,	as LISTID,	AM,	TM,	QUEID,	WR,				ENDIAN */
#define MCVX_VCP3_VP_VLC_DCHR_LIL( ENDIAN )					MCVX_VCP3_FMT_CMN_DCHR_X(	0x0001u,	0u,			0u,			1u,	0u,	2u,		MCVX_VCP3_CH_R,	( ENDIAN ) )

/* IMD STUFF (VLC) */																/*	VP_ADDR,	as BAAP,	as LISTID,	AM,	TM,	QUEID,	WR,				ENDIAN */
#define MCVX_VCP3_VP_VLC_DCHR_R_IMS( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0018u,	27u,		5u,			0u,	1u,	0u,		MCVX_VCP3_CH_R,	( ENDIAN ) )
#define MCVX_VCP3_VP_VLC_DCHR_R_IMC( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0019u,	28u,		6u,			0u,	1u,	0u,		MCVX_VCP3_CH_R,	( ENDIAN ) )
#define MCVX_VCP3_VP_VLC_DCHR_W_IMS( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0018u,	27u,		5u,			0u,	1u,	0u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#define MCVX_VCP3_VP_VLC_DCHR_W_IMC( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0019u,	28u,		6u,			0u,	1u,	0u,		MCVX_VCP3_CH_W,	( ENDIAN ) )

/* MISC STUFF (VLC) */																/*	VP_ADDR,	as BAAP,	as LISTID,	AM,	TM,	QUEID,	WR,				ENDIAN */
#define MCVX_VCP3_VP_VLC_DCHR_R_MBI( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0010u,	0u,			0u,			0u,	0u,	1u,		MCVX_VCP3_CH_R,	( ENDIAN ) )
#define MCVX_VCP3_VP_VLC_DCHR_W_MBI( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0011u,	0u,			0u,			0u,	0u,	1u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#define MCVX_VCP3_VP_VLC_DCHR_R_COL( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0012u,	0u,			0u,			0u,	0u,	1u,		MCVX_VCP3_CH_R,	( ENDIAN ) )
#define MCVX_VCP3_VP_VLC_DCHR_W_COL( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0013u,	0u,			0u,			0u,	0u,	1u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#define MCVX_VCP3_VP_VLC_DCHR_R_DPBPSEG( ENDIAN )			MCVX_VCP3_FMT_CMN_DCHR_X(	0x0014u,	0u,			0u,			0u,	0u,	1u,		MCVX_VCP3_CH_R,	( ENDIAN ) )
#define MCVX_VCP3_VP_VLC_DCHR_W_DPBPSEG( ENDIAN )			MCVX_VCP3_FMT_CMN_DCHR_X(	0x0015u,	0u,			0u,			0u,	0u,	1u,		MCVX_VCP3_CH_W,	( ENDIAN ) )

/* MISC STUFF (VLC) (ENC) */														/*	VP_ADDR,	as BAAP,	as LISTID,	AM,	TM,	QUEID,	WR,				ENDIAN */
#define MCVX_VCP3_VP_VLC_DCHR_W_ENC_DP_COEF0( ENDIAN )		MCVX_VCP3_FMT_CMN_DCHR_X(	0x000Eu,	25u,		3u,			0u,	1u,	0u,		MCVX_VCP3_CH_W,	( ENDIAN ) )	/* share with COEF0 */
#define MCVX_VCP3_VP_VLC_DCHR_W_ENC_DP_COEF1( ENDIAN )		MCVX_VCP3_FMT_CMN_DCHR_X(	0x000Fu,	26u,		4u,			0u,	1u,	0u,		MCVX_VCP3_CH_W,	( ENDIAN ) )	/* share with COEF1 */
#define MCVX_VCP3_VP_VLC_DCHR_W_ENC_STAT( ENDIAN )			MCVX_VCP3_FMT_CMN_DCHR_X(	0x0015u,	0u,			0u,			0u,	0u,	1u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#define MCVX_VCP3_VP_VLC_DCHR_R_ENC_PROB( ENDIAN )			MCVX_VCP3_FMT_CMN_DCHR_X(	0x0012u,	0u,			0u,			0u,	0u,	1u,		MCVX_VCP3_CH_R,	( ENDIAN ) )
#define MCVX_VCP3_VP_VLC_DCHR_R_ENC_DP_COEF( ENDIAN )		MCVX_VCP3_FMT_CMN_DCHR_X(	0x0014u,	0u,			0u,			0u,	0u,	1u,		MCVX_VCP3_CH_R,	( ENDIAN ) )

/* see hw-manual Table 3-67: Description of DMA channel registers of CE */
/* IMD STUFF (CE) */																/*	VP_ADDR,	as BAAP,	as LISTID,	AM,	TM,	QUEID,	WR,				ENDIAN */
#define MCVX_VCP3_VP_CE_DCHR_R_IMS( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0018u,	16u,		0u,			0u,	1u,	1u,		MCVX_VCP3_CH_R,	( ENDIAN ) ) /* queue_id=1 */
#define MCVX_VCP3_VP_CE_DCHR_R_IMC( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0019u,	17u,		1u,			0u,	1u,	0u,		MCVX_VCP3_CH_R,	( ENDIAN ) )	
#define MCVX_VCP3_VP_CE_DCHR_W_IMS( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0018u,	16u,		0u,			0u,	1u,	0u,		MCVX_VCP3_CH_W,	( ENDIAN ) )	
#define MCVX_VCP3_VP_CE_DCHR_W_IMC( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0019u,	17u,		1u,			0u,	1u,	0u,		MCVX_VCP3_CH_W,	( ENDIAN ) )	

/* MISC STUFF (CE) */																/*	VP_ADDR,	as BAAP,	as LISTID,	AM,	TM,	QUEID,	WR,				ENDIAN */
#define MCVX_VCP3_VP_CE_DCHR_R_MBI( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0010u,	0u,			0u,			0u,	0u,	0u,		MCVX_VCP3_CH_R,	( ENDIAN ) )	/* queue_id=0 */
#define MCVX_VCP3_VP_CE_DCHR_W_MBI( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0011u,	0u,			0u,			0u,	0u,	1u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_R_COL( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0012u,	0u,			0u,			0u,	0u,	1u,		MCVX_VCP3_CH_R,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_W_COL( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0013u,	0u,			0u,			0u,	0u,	1u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_R_3LM( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0014u,	0u,			0u,			0u,	0u,	1u,		MCVX_VCP3_CH_R,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_W_3LM( ENDIAN )				MCVX_VCP3_FMT_CMN_DCHR_X(	0x0015u,	0u,			0u,			0u,	0u,	1u,		MCVX_VCP3_CH_W,	( ENDIAN ) )

/* IMAGE STUFF */																	/*	VP_ADDR,	DECPIC, YC,	TOPBOT,	TILEVSIZE,			TILEHSIZE,			AM,	TM,	QUEID,	WR,				ENDIAN */
#define MCVX_VCP3_VP_CE_DCHR_R_REF_Y( ENDIAN )				MCVX_VCP3_FMT_IMG_DCHR_X(	0x0003u,	0u,		0u,	0u,		MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	4u,		MCVX_VCP3_CH_R,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_R_REF_C( ENDIAN )				MCVX_VCP3_FMT_IMG_DCHR_X(	0x0004u,	0u,		0u,	0u,		MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	4u,		MCVX_VCP3_CH_R,	( ENDIAN ) )

#define MCVX_VCP3_VP_CE_DCHR_R_ENC_Y_LN( ENDIAN )			MCVX_VCP3_FMT_IMG_DCHR_X(	0x0005u,	0u,		0u,	0u,		0u,					0u,					0u,	0u,	4u,		MCVX_VCP3_CH_R,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_R_ENC_C_LN( ENDIAN )			MCVX_VCP3_FMT_IMG_DCHR_X(	0x0006u,	0u,		0u,	0u,		0u,					0u,					0u,	0u,	4u,		MCVX_VCP3_CH_R,	( ENDIAN ) )

#define MCVX_VCP3_VP_CE_DCHR_R_ENC_Y_XY( ENDIAN )			MCVX_VCP3_FMT_IMG_DCHR_X(	0x0005u,	0u,		0u,	0u,		MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	4u,		MCVX_VCP3_CH_R,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_R_ENC_C_XY( ENDIAN )			MCVX_VCP3_FMT_IMG_DCHR_X(	0x0006u,	0u,		0u,	0u,		MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	4u,		MCVX_VCP3_CH_R,	( ENDIAN ) )

#define MCVX_VCP3_VP_CE_DCHR_W_DEC_Y( ENDIAN, TOPBOT )		MCVX_VCP3_FMT_IMG_DCHR_X(	0x0007u,	1u,		0u,	TOPBOT,	MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	2u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_W_DEC_C( ENDIAN, TOPBOT )		MCVX_VCP3_FMT_IMG_DCHR_X(	0x0008u,	1u,		1u,	TOPBOT,	MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	2u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_W_FLT_Y( ENDIAN, TOPBOT )		MCVX_VCP3_FMT_IMG_DCHR_X(	0x0009u,	0u,		0u,	TOPBOT,	MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	2u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_W_FLT_C( ENDIAN, TOPBOT )		MCVX_VCP3_FMT_IMG_DCHR_X(	0x000Au,	0u,		1u,	TOPBOT,	MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	2u,		MCVX_VCP3_CH_W,	( ENDIAN ) )

#define MCVX_VCP3_VP_CE_DCHR_W_DEC_BOT_Y( ENDIAN )			MCVX_VCP3_FMT_IMG_DCHR_X(	0x001Au,	1u,		0u,	1u,		MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	2u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_W_DEC_BOT_C( ENDIAN )			MCVX_VCP3_FMT_IMG_DCHR_X(	0x001Bu,	1u,		1u,	1u,		MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	2u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_W_FLT_BOT_Y( ENDIAN )			MCVX_VCP3_FMT_IMG_DCHR_X(	0x001Cu,	0u,		0u,	1u,		MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	2u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_W_FLT_BOT_C( ENDIAN )			MCVX_VCP3_FMT_IMG_DCHR_X(	0x001Du,	0u,		1u,	1u,		MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	2u,		MCVX_VCP3_CH_W,	( ENDIAN ) )

/* FCV STUFF */	
#define MCVX_VCP3_VP_CE_DCHR_R_FCV_Y( ENDIAN )				MCVX_VCP3_FMT_IMG_DCHR_X(	0x000Bu,	0u,		0u,	0u,		MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	3u,		MCVX_VCP3_CH_R,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_R_FCV_C( ENDIAN )				MCVX_VCP3_FMT_IMG_DCHR_X(	0x000Cu,	0u,		0u,	0u,		MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	3u,		MCVX_VCP3_CH_R,	( ENDIAN ) )
#if 0
#define MCVX_VCP3_VP_CE_DCHR_W_FCV_Y( ENDIAN )				MCVX_VCP3_FMT_IMG_DCHR_X(	0x000Du,	0u,		0u,	0u,		MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	2u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_W_FCV_C( ENDIAN )				MCVX_VCP3_FMT_IMG_DCHR_X(	0x000Eu,	0u,		0u,	0u,		MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	2u,	0u,	2u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#else
#define MCVX_VCP3_VP_CE_DCHR_W_FCV_Y( ENDIAN )				MCVX_VCP3_FMT_IMG_DCHR_X(	0x000Du,	0u,		0u,	0u,		MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	0u,	0u,	1u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#define MCVX_VCP3_VP_CE_DCHR_W_FCV_C( ENDIAN )				MCVX_VCP3_FMT_IMG_DCHR_X(	0x000Eu,	0u,		0u,	0u,		MCVX_VCP3_TL_V32,	MCVX_VCP3_TL_H128,	0u,	0u,	1u,		MCVX_VCP3_CH_W,	( ENDIAN ) )
#endif

/*----------------------------------------------------------------------------------------------------------*/
/*							                                                                                */
/* LIST ITEM				                                                                                */
/*							                                                                                */
/*----------------------------------------------------------------------------------------------------------*/
/* LIST TEMPLATE */
#define MCVX_VCP3_FMT_VP_LIST( LIST_OFFSET, TERM, SIZE, BITPOS, ADDR )				\
	do{ 																			\
		MCVX_IR_W0 = 0u;															\
		MCVX_IR_W1 = ( MCVX_VCP3_VP_ADDR_TOP + ( LIST_OFFSET ) );					\
		MCVX_IR_W2 = ( ( ( MCVX_M_01BIT & ( TERM ) )	<< (59-32) )				\
					 | ( ( MCVX_M_24BIT & ( SIZE ) )	<< (35-32) )				\
					 | ( ( MCVX_M_03BIT & ( BITPOS ) ) 	<< (32-32) ) );				\
		MCVX_IR_W3 = ( ADDR );	 													\
		tail += MCVX_IR_SIZEOF_4W; 													\
	}while(0)

#define MCVX_VCP3_VP_LIST_SINGLE( OFFSET0, ADDR0, SIZE0, BITPOS0 )							\
	do{ 																					\
		MCVX_VCP3_FMT_VP_LIST( OFFSET0, 1u, SIZE0, BITPOS0,	ADDR0 );						\
	}while(0)

#define MCVX_VCP3_VP_LIST_DOUBLE( OFFSET0, OFFSET1, ADDR0, SIZE0, BITPOS0, ADDR1, SIZE1 )	\
	do{ 																					\
		if( ( SIZE1 ) == 0u ){																\
			MCVX_VCP3_FMT_VP_LIST( OFFSET0, 1u, SIZE0, BITPOS0,	ADDR0 );					\
		}																					\
		else{																				\
			MCVX_VCP3_FMT_VP_LIST( OFFSET0, 0u, SIZE0, BITPOS0,	ADDR0 );					\
			MCVX_VCP3_FMT_VP_LIST( OFFSET1, 1u, SIZE1, 0u,		ADDR1 );					\
		}																					\
	}while(0)

/** \test WORKAROUND : #42503 [CDMAC/VDMAC] cannot receive AXI response correctly when two or more commands are list over */
#define MCVX_VCP3_VP_VLC_LIST_ES_SUB( ADDR0, SIZE0, BITPOS0, ADDR1, SIZE1 )					\
	do{ 																					\
		if( ( SIZE1 ) == 0u ){																\
			MCVX_VCP3_FMT_VP_LIST( 0x00c8, 1u, ((SIZE0) + 1024u), BITPOS0,	ADDR0 );		\
		}																					\
		else{																				\
			MCVX_VCP3_FMT_VP_LIST( 0x00c8, 0u, SIZE0,				BITPOS0,	ADDR0 );	\
			MCVX_VCP3_FMT_VP_LIST( 0x00c9, 1u, ((SIZE1) + 1024u),	0u,			ADDR1 );	\
		}																					\
	}while(0)

/* LIST IMD(VLC) */
#define MCVX_VCP3_VP_VLC_LIST_IMS( ADDR0, SIZE0, ADDR1, SIZE1 )						MCVX_VCP3_VP_LIST_DOUBLE( 0x00d2, 0x00d3, ADDR0, SIZE0, 0u,		ADDR1, SIZE1 )
#define MCVX_VCP3_VP_VLC_LIST_IMC( ADDR0, SIZE0 )									MCVX_VCP3_VP_LIST_SINGLE( 0x00d4,		  ADDR0, SIZE0, 0u					 )

/* LIST IMD(CE) */
#define MCVX_VCP3_VP_CE_LIST_IMS( ADDR0, SIZE0, ADDR1, SIZE1 )						MCVX_VCP3_VP_LIST_DOUBLE( 0x0100, 0x0101, ADDR0, SIZE0, 0u,		ADDR1, SIZE1 )
#define MCVX_VCP3_VP_CE_LIST_IMC( ADDR0, SIZE0 )									MCVX_VCP3_VP_LIST_SINGLE( 0x0102,		  ADDR0, SIZE0, 0u					 )

/* LIST ENC DP0 (VLC) */
#define MCVX_VCP3_VP_VLC_LIST_ENC_DP_COEF0( ADDR, SIZE )							MCVX_VCP3_VP_LIST_SINGLE( 0x00d0,		  ADDR,  SIZE,	0u					 )
#define MCVX_VCP3_VP_VLC_LIST_ENC_DP_COEF1( ADDR, SIZE )							MCVX_VCP3_VP_LIST_SINGLE( 0x00d1,		  ADDR,	 SIZE,	0u					 )

/*----------------------------------------------------------------------------------------------------------*/
/*							                                                                                */
/* VLC PAR					                                                                                */
/*							                                                                                */
/*----------------------------------------------------------------------------------------------------------*/

/* VLC PAR */																	/*	EMASK,	VP_ADDRESS,					DATA[63:32],	DATA[31: 0] */
#define MCVX_VCP3_VP_VLC_PAR0( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x00,	0x01000010u,				DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_VLC_PAR1( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x00,	0x01000011u,				DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_VLC_PAR2( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x00,	0x01000012u,				DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_VLC_PAR3( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x00,	0x01000013u,				DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_VLC_PAR4( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x00,	0x01000014u,				DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_VLC_PAR5( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x00,	0x01000015u,				DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_VLC_PAR6( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x00,	0x01000016u,				DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_VLC_PAR7( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x00,	0x01000017u,				DATA_H,			DATA_L		)

/* VLC_PIC_SIZE0/1 */															/*	EMASK,	VP_ADDRESS,					DATA[63:32],	DATA[31: 0] */
#define MCVX_VCP3_VP_VLC_PIC_SIZE0( PIC_SIZE )					MCVX_VCP3_FMT_DATA(	0x00,	0x01000001u,				0u,				PIC_SIZE	)
#define MCVX_VCP3_VP_VLC_PIC_SIZE1( PIC_SIZE )					MCVX_VCP3_FMT_DATA(	0x00,	0x01000002u,				0u,				PIC_SIZE	)

/* AVCD */																		/*	EMASK,	VP_ADDRESS,					DATA[63:32],	DATA[31: 0] */
#define MCVX_VCP3_VP_VLC_MVRINFO( MVRINFO )						MCVX_VCP3_FMT_DATA(	0x00,	( 0x01000040u			),	0u,				MVRINFO		)
#define MCVX_VCP3_VP_VLC_REF_POC( POC_H, POC_L, CNT )			MCVX_VCP3_FMT_DATA(	0x00,	( 0x01000060u + ( CNT ) ),	POC_H,			POC_L		)
#define MCVX_VCP3_VP_VLC_CUR_POC( POC_0, POC_1 )				MCVX_VCP3_FMT_DATA(	0x00,	( 0x01000070u			),	POC_0,			POC_1		)
#define MCVX_VCP3_VP_VLC_WP_TBL_L0( WPT_H, WPT_L, CNT )			MCVX_VCP3_FMT_DATA(	0x00,	( 0x01000080u + ( CNT ) ),	WPT_H,			WPT_L		)
#define MCVX_VCP3_VP_VLC_WP_TBL_L1( WPT_H, WPT_L, CNT )			MCVX_VCP3_FMT_DATA(	0x00,	( 0x010000a0u + ( CNT ) ),	WPT_H,			WPT_L		)
#define MCVX_VCP3_VP_VLC_REF_TBL( UID_H, UID_L, CNT )			MCVX_VCP3_FMT_DATA(	0x00,	( 0x010000C0u + ( CNT ) ),	UID_H,			UID_L		)
#define MCVX_VCP3_VP_VLC_INITREF_P( UID_H, UID_L, CNT )			MCVX_VCP3_FMT_DATA(	0x00,	( 0x010000C8u + ( CNT ) ),	UID_H,			UID_L		)
#define MCVX_VCP3_VP_VLC_INITREF_B_L0( UID_H, UID_L, CNT )		MCVX_VCP3_FMT_DATA(	0x00,	( 0x010000D8u + ( CNT ) ),	UID_H,			UID_L		)
#define MCVX_VCP3_VP_VLC_INITREF_B_L1( UID_H, UID_L, CNT )		MCVX_VCP3_FMT_DATA(	0x00,	( 0x010000E8u + ( CNT ) ),	UID_H,			UID_L		)

/* VC1D */																		/*	EMASK,	VP_ADDRESS,					DATA[63:32],	DATA[31: 0] */
#define MCVX_VCP3_VP_VLC_BYTE_DATA( DATA )						MCVX_VCP3_FMT_DATA(	0x00,	( 0x01000003u		   ),	0u,				DATA		)

/* VP6D */																		/*	EMASK,	VP_ADDRESS,					DATA[63:32],	DATA[31: 0] */
#define MCVX_VCP3_VP_VLC_CSO( DATA_H, DATA_L, CNT )				MCVX_VCP3_FMT_DATA(	0x00,	( 0x010000C0u + ( CNT ) ),	DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_VLC_MPI( DATA_H, DATA_L, CNT )				MCVX_VCP3_FMT_DATA(	0x00,	( 0x01000100u + ( CNT ) ),	DATA_H,			DATA_L		)

/* RLVD */
#define MCVX_VCP3_VP_VLC_MAI( OSVQUANT, SQUANT, MBA, BYTEOFFSET )					\
	do{																				\
		MCVX_IR_W0 =( ( ( MCVX_M_02BIT & ( OSVQUANT ) )			<< (125-96) )		\
					| ( ( MCVX_M_05BIT & ( SQUANT ) )			<< (120-96) ) );	\
		MCVX_IR_W1 =  ( ( MCVX_M_16BIT & ( MBA ) )				<< ( 64-64) );		\
		MCVX_IR_W2 = 0x00000000u;													\
		MCVX_IR_W3 =  ( ( MCVX_M_32BIT & ( BYTEOFFSET ) )		<< (  0- 0) );		\
		tail += MCVX_IR_SIZEOF_4W; 													\
	}while(0)

#define MCVX_VCP3_VP_VLC_MAI_LAST													\
	do{																				\
		MCVX_IR_W0 = 0xffffffffu;													\
		MCVX_IR_W1 = 0xffffffffu;													\
		MCVX_IR_W2 = 0xffffffffu;													\
		MCVX_IR_W3 = 0xffffffffu;													\
		tail += MCVX_IR_SIZEOF_4W; 													\
	}while(0)

#define MCVX_VCP3_VP_VLC_DMA_STR_CTRL( OTSD_ONE, USE_STB )							\
	do{																				\
		MCVX_IR_W0 = 0x00000000u;													\
		MCVX_IR_W1 = 0x08000028u;													\
		MCVX_IR_W2 = 0x00000000u;													\
		MCVX_IR_W3 =( ( ( MCVX_M_01BIT & ( OTSD_ONE ) )				<<		1 )		\
					| ( ( MCVX_M_01BIT & ( USE_STB ) )				<<		0 ) );	\
		tail += MCVX_IR_SIZEOF_4W; 													\
	}while(0)

/* Encoder */																	/*	EMASK,	VP_ADDRESS,					DATA[63:32],	DATA[31: 0] */
#define MCVX_VCP3_VP_VLC_SH0( OFFSET_BYTE )						MCVX_VCP3_FMT_DATA(	0x00,	( 0x01000020u		    ),	0u,				OFFSET_BYTE		)
#define MCVX_VCP3_VP_VLC_SH5( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x00,	( 0x01000025u		    ),	DATA_H,			DATA_L			)
#define MCVX_VCP3_VP_VLC_SH6_13( SD_H, SD_L, CNT )				MCVX_VCP3_FMT_DATA(	0x00,	( 0x01000026u + ( CNT ) ),	SD_H,			SD_L			)
/* VP_VLC_SH14 (removed) */
#define MCVX_VCP3_VP_VLC_SH15( DATA_L )							MCVX_VCP3_FMT_DATA(	0x00,	( 0x0100002Fu		    ),	0u,				DATA_L			)
#define MCVX_VCP3_VP_VLC_SH16( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x00,	( 0x01000030u		    ),	DATA_H,			DATA_L			)

#define MCVX_VCP3_VP_VLC_SH1_4( PAD_H, PAD_L, CNT )				MCVX_VCP3_FMT_DATA(	0x00,	( 0x01000021u + ( CNT ) ),	PAD_H,			PAD_L			)
#define MCVX_VCP3_VP_VLC_SH17_28( PAD_H, PAD_L, CNT )			MCVX_VCP3_FMT_DATA(	0x00,	( 0x01000031u + ( CNT ) ),	PAD_H,			PAD_L			)

#define MCVX_VCP3_VP_VLC_SWITCH( IMSB_MODE, EC_MODE, EC_RCV, EC_ALL_PIC, DEC_NALT_20 )	\
	do{																					\
		MCVX_IR_W0 = 0x00000000u;														\
		MCVX_IR_W1 = 0x01000000u;														\
		MCVX_IR_W2 =( ( ( MCVX_M_01BIT & ( IMSB_MODE )	)			<<	(63-32) )		\
					| ( ( MCVX_M_01BIT & ( EC_MODE ) )				<<	(34-32) )		\
					| ( ( MCVX_M_01BIT & ( EC_RCV ) )				<<	(33-32) )		\
					| ( ( MCVX_M_01BIT & ( EC_ALL_PIC ) )			<<	(32-32) ) );	\
		MCVX_IR_W3 =( ( ( MCVX_M_01BIT & ( DEC_NALT_20 ) )			<<		26	) );	\
		tail += MCVX_IR_SIZEOF_4W; 														\
	}while(0)

/*----------------------------------------------------------------------------------------------------------*/
/*							                                                                                */
/* CE PAR					                                                                                */
/*							                                                                                */
/*----------------------------------------------------------------------------------------------------------*/

																					/*	EMASK,	VP_ADDRESS,		DATA[63:32],	DATA[31: 0] */
#define MCVX_VCP3_VP_CE_PAR0( DATA_H, DATA_L )						MCVX_VCP3_FMT_DATA(	0x07,	0x00000010u,	DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_CE_PAR1( DATA_H, DATA_L )						MCVX_VCP3_FMT_DATA(	0x07,	0x00000011u,	DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_CE_PAR2( DATA_H, DATA_L )						MCVX_VCP3_FMT_DATA(	0x07,	0x00000012u,	DATA_H,			DATA_L		)

#define MCVX_VCP3_VP_CE_PAR4( DATA_H, DATA_L )						MCVX_VCP3_FMT_DATA(	0x07,	0x03000014u,	DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_CE_PAR5( DATA_H, DATA_L )						MCVX_VCP3_FMT_DATA(	0x07,	0x03000015u,	DATA_H,			DATA_L		)

/* CE USER ID */																	/*	EMASK,	VP_ADDRESS,					DATA[63:32],	DATA[31: 0] */
#define MCVX_VCP3_VP_CE_USER_ID( USER_ID )							MCVX_VCP3_FMT_DATA(	0x00,	0x000000C4u,	0u,				USER_ID		)

/* Encoder */
#define MCVX_VCP3_VP_CE_SLC_SIZE( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x00,	0x00000000u,	DATA_H,			DATA_L		)

#define MCVX_VCP3_VP_CE_ENC_CTRL0( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x07,	0x00000019u,	DATA_H,			DATA_L		)	/* CCTL */
#define MCVX_VCP3_VP_CE_ENC_CTRL1( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x07,	0x0200001au,	DATA_H,			DATA_L		)	/* MEC */
#define MCVX_VCP3_VP_CE_ENC_CTRL2( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x07,	0x0200001bu,	DATA_H,			DATA_L		)	/* MEC */
#define MCVX_VCP3_VP_CE_TMP_CTRL( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x00,	0x02000003u,	DATA_H,			DATA_L		)	/* MEC */

#define MCVX_VCP3_VP_CE_TMP_Y_BA( DATA_L )							MCVX_VCP3_FMT_DATA(	0x00,	0x020000a0u,	0u,				DATA_L		)	/* VCP3rev3 or later */
#define MCVX_VCP3_VP_CE_TMP_C_BA0( DATA_L )							MCVX_VCP3_FMT_DATA(	0x00,	0x020000a1u,	0u,				DATA_L		)	/* VCP3rev3 or later */
#define MCVX_VCP3_VP_CE_TMP_C_BA1( DATA_L )							MCVX_VCP3_FMT_DATA(	0x00,	0x020000a2u,	0u,				DATA_L		)	/* VCP3rev3 or later */

#define MCVX_VCP3_VP_CE_INTRA_REFRESH( DATA_H, DATA_L )				MCVX_VCP3_FMT_DATA(	0x00,	0x04000002u,	DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_CE_INTRA_CTRL0( DATA_H, DATA_L )				MCVX_VCP3_FMT_DATA(	0x07,	0x04000060u,	DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_CE_INTRA_CTRL1( DATA_H, DATA_L )				MCVX_VCP3_FMT_DATA(	0x07,	0x04000061u,	DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_CE_INTER_CTRL( DATA_H, DATA_L )				MCVX_VCP3_FMT_DATA(	0x07,	0x04000068u,	DATA_H,			DATA_L		)

#define MCVX_VCP3_VP_CE_INTRA_CTRL0_WA( DATA_H, DATA_L )			MCVX_VCP3_FMT_DATA(	0x00,	0x04000000u,	DATA_H,			DATA_L		)

#define MCVX_VCP3_VP_CE_RATE_CTRL0( DATA_H, DATA_L )				MCVX_VCP3_FMT_DATA(	0x00,	0x03000050u,	DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_CE_RATE_CTRL1( DATA_H, DATA_L )				MCVX_VCP3_FMT_DATA(	0x00,	0x03000051u,	DATA_H,			DATA_L		)
#define MCVX_VCP3_VP_CE_COST_CTRL( DATA_H, DATA_L )					MCVX_VCP3_FMT_DATA(	0x00,	0x03000058u,	DATA_H,			DATA_L		)

#define MCVX_VCP3_VP_CE_IS_BUFF_TH( DATA_H, DATA_L )				MCVX_VCP3_FMT_DATA(	0x00,	0x01000000u,	DATA_H,			DATA_L		)

#define MCVX_VCP3_VP_CE_DMA_TMP_LINEAR( TMP_LINEAR )								\
	do{																				\
		MCVX_IR_W0 = 0x00000000u;													\
		MCVX_IR_W1 = 0x08000027u;													\
		MCVX_IR_W2 = 0x00000000u;													\
		MCVX_IR_W3 = ( ( ( MCVX_M_01BIT & ( TMP_LINEAR ) )			<<		0 ) );	\
		tail += MCVX_IR_SIZEOF_4W; 													\
	}while(0)

#define MCVX_VCP3_VP_CE_DMA_PORT_CTRL( IMR_PORT_DISABLE, CAXI2_PORT_DISABLE )		\
	do{																				\
		MCVX_IR_W0 = 0x00000000u;													\
		MCVX_IR_W1 = 0x08000028u;													\
		MCVX_IR_W2 = 0x00000000u;													\
		MCVX_IR_W3 =( ( ( MCVX_M_01BIT & ( IMR_PORT_DISABLE ) )		<<		1 )		\
					| ( ( MCVX_M_01BIT & ( CAXI2_PORT_DISABLE ) )	<<		0 ) );	\
		tail += MCVX_IR_SIZEOF_4W; 													\
	}while(0)

#define MCVX_VCP3_VP_CE_DMA_USE_REFBUF( USE_REFBUF )								\
	do{																				\
		MCVX_IR_W0 = 0x00000000u;													\
		MCVX_IR_W1 = 0x08000029u;													\
		MCVX_IR_W2 = 0x00000000u;													\
		MCVX_IR_W3 =( ( ( MCVX_M_01BIT & ( USE_REFBUF ) )			<<		0 ) );	\
		tail += MCVX_IR_SIZEOF_4W; 													\
	}while(0)

#define MCVX_VCP3_VP_CE_DMA_WCMD_SEPARATE( WCMD_SEP )								\
	do{																				\
		MCVX_IR_W0 = 0x00000000u;													\
		MCVX_IR_W1 = 0x0800002Bu;													\
		MCVX_IR_W2 = 0x00000000u;													\
		MCVX_IR_W3 =( ( ( MCVX_M_01BIT & ( WCMD_SEP ) )				<<		0 ) );	\
		tail += MCVX_IR_SIZEOF_4W; 													\
	}while(0)

#define MCVX_VCP3_VP_CE_SWITCH( IMSB_MODE, EC_ALL_PIC, EC_MODE, DEB_PASSTHRU )			\
	do{																					\
		MCVX_IR_W0 = ( MCVX_M_06BIT & ( 0x07 ) ) << 24;									\
		MCVX_IR_W1 = 0x01000018u;														\
		MCVX_IR_W2 =( ( ( MCVX_M_01BIT & ( IMSB_MODE )	)			<<	(63-32) ) );	\
		MCVX_IR_W3 =( ( ( MCVX_M_01BIT & ( EC_ALL_PIC )	)			<<		27  )		\
					| ( ( MCVX_M_01BIT & ( EC_MODE ) )				<<		26	)		\
					| ( ( MCVX_M_01BIT & ( DEB_PASSTHRU ) )			<<		25	)		\
					| ( ( MCVX_M_01BIT & ( MCVX_FALSE ) )			<<		24	)		\
					| ( ( MCVX_M_08BIT & ( MCVX_EC_FILL_Y ) )		<<		16	)		\
					| ( ( MCVX_M_08BIT & ( MCVX_EC_FILL_U ) )		<<		 8	)		\
					| ( ( MCVX_M_08BIT & ( MCVX_EC_FILL_V ) )		<<		 0	) );	\
		tail += MCVX_IR_SIZEOF_4W; 														\
	}while(0)

/*----------------------------------------------------------------------------------------------------------*/
/*							                                                                                */
/* CMN REG					                                                                                */
/*							                                                                                */
/*----------------------------------------------------------------------------------------------------------*/	
#define MCVX_VCP3_REG_PBAL( IRP_SIZE, ENDIAN )										\
	( ( ( MCVX_M_01BIT & 1u )											<< 31 )		\
	| ( ( MCVX_M_08BIT & ( ( ( ( IRP_SIZE ) + 127u ) / 128u ) - 1u ) )	<< 14 )		\
	| ( ( MCVX_M_03BIT & 1u )											<< 11 )		\
	| ( ( MCVX_M_02BIT & 3u )											<<  9 )		\
	| ( ( MCVX_M_03BIT & 2u )											<<  6 )		\
	| ( ( MCVX_M_05BIT & ( ENDIAN ) )									<<  0 ) )	\

/*----------------------------------------------------------------------------------------------------------*/
/*							                                                                                */
/* VLC REG					                                                                                */
/*							                                                                                */
/*----------------------------------------------------------------------------------------------------------*/	
#define MCVX_VCP3_REG_VLC_LIST_INIT( L0, L1, L2, L3, L4, L5, L6 )	\
	( ( ( MCVX_M_01BIT & ( L6 ) )				<<  6 )				\
	| ( ( MCVX_M_01BIT & ( L5 ) )				<<  5 )				\
	| ( ( MCVX_M_01BIT & ( L4 ) )				<<  4 )				\
	| ( ( MCVX_M_01BIT & ( L3 ) )				<<  3 )				\
	| ( ( MCVX_M_01BIT & ( L2 ) )				<<  2 )				\
	| ( ( MCVX_M_01BIT & ( L1 ) )				<<  1 )				\
	| ( ( MCVX_M_01BIT & ( L0 ) )				<<  0 ) )			\

#define MCVX_VCP3_REG_VLC_LIST_EN( L0, L1, L2, L3, L4, L5, L6 )		\
	( ( ( MCVX_M_01BIT & ( L6 ) )				<<  6 )				\
	| ( ( MCVX_M_01BIT & ( L5 ) )				<<  5 )				\
	| ( ( MCVX_M_01BIT & ( L4 ) )				<<  4 )				\
	| ( ( MCVX_M_01BIT & ( L3 ) )				<<  3 )				\
	| ( ( MCVX_M_01BIT & ( L2 ) )				<<  2 )				\
	| ( ( MCVX_M_01BIT & ( L1 ) )				<<  1 )				\
	| ( ( MCVX_M_01BIT & ( L0 ) )				<<  0 ) )			\

#define MCVX_VCP3_REG_VLC_LIST_LDEN( L0 )							\
	( ( ( MCVX_M_01BIT & ( L0 ) )				<<  0 ) )			\

#define MCVX_VCP3_REG_VLC_CTRL( MODE, STREAM_TYPE )					\
	( ( ( MCVX_M_01BIT & ( MODE ) )				<<  31 )			\
	| ( ( MCVX_M_05BIT & ( STREAM_TYPE ) )		<<  16 )			\
	| ( ( MCVX_M_03BIT & ( 0u ) )				<<   0 ) )			\

/*----------------------------------------------------------------------------------------------------------*/
/*							                                                                                */
/* CE REG					                                                                                */
/*							                                                                                */
/*----------------------------------------------------------------------------------------------------------*/	
#define MCVX_VCP3_REG_CE_LIST_INIT( L0, L1 )						\
	( ( ( MCVX_M_01BIT & ( L1 ) )				<<  1 )				\
	| ( ( MCVX_M_01BIT & ( L0 ) )				<<  0 ) )			\

#define MCVX_VCP3_REG_CE_LIST_EN( L0, L1 )							\
	( ( ( MCVX_M_01BIT & ( L1 ) )				<<  1 )				\
	| ( ( MCVX_M_01BIT & ( L0 ) )				<<  0 ) )			\

#define MCVX_VCP3_REG_CE_CTRL( MODE )								\
	( ( ( MCVX_M_01BIT & ( MODE ) )				<<  31 )			\
	| ( ( MCVX_M_03BIT & ( 0u ) )				<<  0 ) )			\

/*----------------------------------------------------------------------------------------------------------*/
/*							                                                                                */
/* FCV REG					                                                                                */
/*							                                                                                */
/*----------------------------------------------------------------------------------------------------------*/	
#define MCVX_VCP3_REG_FCV_CTRL( MODE )								\
	( ( ( MCVX_M_01BIT & ( MODE ) )				<<  31 )			\
	| ( ( MCVX_M_03BIT & ( 1u ) )				<<  0 ) )			\

/* for RPR */
#define MCVX_VCP3_VP_CE_FCV_PSIZE( VSIZEDST, HSIZEDST, VSIZESRC, HSIZESRC  )		\
	do{																				\
		MCVX_IR_W0 = 0x00000000u;													\
		MCVX_IR_W1 = 0x07000020u;													\
		MCVX_IR_W2 = 0x00000000u;													\
		MCVX_IR_W3 =( ( ( MCVX_M_01BIT & ( 1u ) )				<<  31 )			\
					| ( ( MCVX_M_07BIT & ( VSIZEDST ) )			<<  24 )			\
					| ( ( MCVX_M_08BIT & ( HSIZEDST ) )			<<  16 )			\
					| ( ( MCVX_M_07BIT & ( VSIZESRC ) )			<<   8 )			\
					| ( ( MCVX_M_08BIT & ( HSIZESRC ) )			<<   0 ) );			\
		tail += MCVX_IR_SIZEOF_4W; 													\
	}while(0)

#define MCVX_VCP3_VP_CE_FCV_ICTRL( N, M, IUXR )										\
	do{																				\
		MCVX_IR_W0 = 0x00000000u;													\
		MCVX_IR_W1 = 0x07000021u;													\
		MCVX_IR_W2 = 0x00000000u;													\
		MCVX_IR_W3 =( ( ( MCVX_M_02BIT & ( 2u ) )				<<  30 )			\
					| ( ( MCVX_M_01BIT & ( ( IUXR ) >> 20 ) )	<<  28 )			\
					| ( ( MCVX_M_04BIT & ( N ) )				<<  24 )			\
					| ( ( MCVX_M_04BIT & ( M ) )				<<  20 )			\
					| ( ( MCVX_M_20BIT & ( IUXR ) )				<<   0 ) );			\
		tail += MCVX_IR_SIZEOF_4W; 													\
	}while(0)

#define MCVX_VCP3_VP_CE_FCV_OCTRL( VEDGESRC, HEDGESRC, IUYLB )						\
	do{																				\
		MCVX_IR_W0 = 0x00000000u;													\
		MCVX_IR_W1 = 0x07000022u;													\
		MCVX_IR_W2 = 0x00000000u;													\
		MCVX_IR_W3 =( ( ( MCVX_M_03BIT & ( VEDGESRC ) )			<<  28 )			\
					| ( ( MCVX_M_03BIT & ( HEDGESRC ) )			<<  24 )			\
					| ( ( MCVX_M_20BIT & ( IUYLB ) )			<<   0 ) );			\
		tail += MCVX_IR_SIZEOF_4W; 													\
	}while(0)

#define MCVX_VCP3_VP_CE_FCV_TLC_CTRL(MODE, STRIDE)					\
	do{																\
		MCVX_IR_W0 = 0x07000000u;									\
		MCVX_IR_W1 = 0x0000001Eu;									\
		MCVX_IR_W2 = 0x00000000u;									\
		MCVX_IR_W3 =( ( ( MCVX_M_12BIT & ( STRIDE ) ) << 16 )  		\
				| ( ( MCVX_M_01BIT & ( MODE ) ) << 0 ) );			\
		tail += MCVX_IR_SIZEOF_4W;									\
	}while(0)

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif  /* #ifndef MCVX_ARCH_VCP3_H */
