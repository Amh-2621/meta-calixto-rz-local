/*************************************************************************/ /*
 UVCS Driver (kernel module)

 Copyright (C) 2015 - 2018 Renesas Electronics Corporation

 License        Dual MIT/GPLv2

 The contents of this file are subject to the MIT license as set out below.

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.

 Alternatively, the contents of this file may be used under the terms of
 the GNU General Public License Version 2 ("GPL") in which case the provisions
 of GPL are applicable instead of those above.

 If you wish to allow use of your version of this file only under the terms of
 GPL, and not to allow others to use your version of this file under the terms
 of the MIT license, indicate your decision by deleting the provisions above
 and replace them with the notice and other provisions required by GPL as set
 out in the file called "GPL-COPYING" included in this distribution. If you do
 not delete the provisions above, a recipient may use your version of this file
 under the terms of either the MIT license or GPL.

 This License is also included in this distribution in the file called
 "MIT-COPYING".

 EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 GPLv2:
 If you wish to use this file under the terms of GPL, following terms are
 effective.

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; version 2 of the License.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/ /*************************************************************************/

#ifndef UVCS_IOCTL_H
#define UVCS_IOCTL_H

#define UVCS_IOCTL_BASE				(0xE0)

#define UVCS_IOCTL_SET_PREEMPT_MODE		_IOW(UVCS_IOCTL_BASE, 0x01, uint)
#define UVCS_IOCTL_CLR_PREEMPT_MODE		_IO(UVCS_IOCTL_BASE, 0x02)
#define UVCS_IOCTL_DUMP_GET_SIZE		_IOR(UVCS_IOCTL_BASE, 0x11, uint *)
#define UVCS_IOCTL_DUMP_OUTPUT			_IOR(UVCS_IOCTL_BASE, 0x12, void *)
#define UVCS_IOCTL_GET_IP_INFO			_IOR(UVCS_IOCTL_BASE, 0x13, void *)
#define UVCS_IOCTL_GET_LSI_INFO			_IOR(UVCS_IOCTL_BASE, 0x14, void *)
#define UVCS_IOCTL_GET_IP_CAPABILITY	_IOR(UVCS_IOCTL_BASE, 0x15, void *)
#define UVCS_IOCTL_SET_USE_IP			_IOW(UVCS_IOCTL_BASE, 0x20, uint)
#define UVCS_IOCTL_CLR_USE_IP			_IO(UVCS_IOCTL_BASE, 0x21)
#define UVCS_IOCTL_GET_SMC                      _IOR(UVCS_IOCTL_BASE, 0x88, void *)

#ifdef CONFIG_COMPAT
#define COMPAT_UVCS_IOCTL_SET_PREEMPT_MODE	_IOW(UVCS_IOCTL_BASE, 0x01, compat_uint_t)
#define COMPAT_UVCS_IOCTL_CLR_PREEMPT_MODE	_IO(UVCS_IOCTL_BASE, 0x02)
#define COMPAT_UVCS_IOCTL_DUMP_GET_SIZE		_IOR(UVCS_IOCTL_BASE, 0x11, compat_uptr_t)
#define COMPAT_UVCS_IOCTL_DUMP_OUTPUT		_IOR(UVCS_IOCTL_BASE, 0x12, compat_uptr_t)
#define COMPAT_UVCS_IOCTL_GET_IP_INFO		_IOR(UVCS_IOCTL_BASE, 0x13, compat_uptr_t)
#define COMPAT_UVCS_IOCTL_GET_LSI_INFO		_IOR(UVCS_IOCTL_BASE, 0x14, compat_uptr_t)
#define COMPAT_UVCS_IOCTL_GET_IP_CAPABILITY	_IOR(UVCS_IOCTL_BASE, 0x15, compat_uptr_t)
#define COMPAT_UVCS_IOCTL_SET_USE_IP		_IOW(UVCS_IOCTL_BASE, 0x20, compat_uint_t)
#define COMPAT_UVCS_IOCTL_CLR_USE_IP		_IO(UVCS_IOCTL_BASE, 0x21)

#endif /* CONFIG_COMPAT */

#endif /* UVCS_IOCTL_H */
